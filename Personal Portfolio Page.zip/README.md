
  # Personal Portfolio Page

  This is a code bundle for Personal Portfolio Page. The original project is available at https://www.figma.com/design/kNtTzFl7XkqEyZSZgdx85P/Personal-Portfolio-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  